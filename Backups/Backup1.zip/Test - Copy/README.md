# Final Project
<h3>Cloning Project</h3>
<ol>
  <li>Create a GitHub Account at <a href="https://github.com/join?source=header-home">https://github.com/join?source=header-home</a></li>
  <li>Go to <a href="https://desktop.github.com">https://desktop.github.com</a> and install GitHub Desktop.</li>
  <li>Log into you account and click add repository</li>
  <li>Use <a href="https://github.com/supperpiecheese/Final-Project.git">https://github.com/supperpiecheese/Final-Project.git</a></li>
</ol>
<h3>Github for Visual Studio</h3>
<ol>
  <li>Download extention at <a href="https://visualstudio.github.com/">https://visualstudio.github.com/</a></li>
  <li>Install the correct Version for your studio (Probably 2017).</li>
  <li>Wait for a litle, then open Visual Studio.</li>
  <li>Go to View, Team Explorer. On the right, under Github, click login.</li>
  <li>Next click "Add" under local Repository, open the previous path made.</li>
  <li>Open the solution file in file explore</li>
</ol>
