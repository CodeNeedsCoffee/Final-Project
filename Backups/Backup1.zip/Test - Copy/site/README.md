# Final Project
<h3>Cloning Project</h3>
<ol>
  <li>Create a GitHub Account at <a href="https://github.com/join?source=header-home">https://github.com/join?source=header-home</a></li>
  <li>Go to <a href="https://desktop.github.com">https://desktop.github.com</a> and install GitHub Desktop.</li>
  <li>Log into you account and click add repository</li>
  <li>Use <a href="https://github.com/supperpiecheese/Final-Project.git">https://github.com/supperpiecheese/Final-Project.git</a>
</ol>
  

