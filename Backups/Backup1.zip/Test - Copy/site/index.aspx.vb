﻿
Partial Class index
    Inherits System.Web.UI.Page

End Class
