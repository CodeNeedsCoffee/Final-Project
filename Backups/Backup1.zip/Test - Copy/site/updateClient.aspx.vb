﻿
Partial Class updateClient
    Inherits System.Web.UI.Page

End Class
