﻿
Partial Class updatePrescription
    Inherits System.Web.UI.Page

End Class
