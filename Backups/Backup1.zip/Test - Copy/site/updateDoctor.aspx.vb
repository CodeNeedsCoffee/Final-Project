﻿
Partial Class updateDoctor
    Inherits System.Web.UI.Page

End Class
