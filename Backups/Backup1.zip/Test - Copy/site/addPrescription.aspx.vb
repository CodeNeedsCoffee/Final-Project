﻿
Partial Class addPrescription
    Inherits System.Web.UI.Page

End Class
