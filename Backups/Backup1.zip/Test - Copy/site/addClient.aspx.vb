﻿
Partial Class addClient
    Inherits System.Web.UI.Page

    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim fname, minit, lname, email, 
    End Sub
End Class
