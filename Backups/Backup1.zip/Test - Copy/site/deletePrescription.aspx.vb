﻿
Partial Class deletePrescription
    Inherits System.Web.UI.Page

End Class
