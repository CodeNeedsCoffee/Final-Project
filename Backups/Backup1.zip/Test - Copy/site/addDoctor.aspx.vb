﻿
Partial Class addDoctor
    Inherits System.Web.UI.Page

End Class
